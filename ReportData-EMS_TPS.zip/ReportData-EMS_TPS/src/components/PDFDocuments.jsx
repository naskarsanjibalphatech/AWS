// PDFDocument.jsx
import React from 'react';
import { Document, Page, View, Text } from '@react-pdf/renderer';
import pdfStyles from './PDFStyles';

const PDFDocument = ({ data, fromDate, toDate }) => (
  <Document>
    <Page size="A4" style={pdfStyles.page}>
      <View style={pdfStyles.section}>
        <Text style={pdfStyles.title}>DynamoDB Data Report</Text>
        <Text style={pdfStyles.filterText}>
          Date Filter: {fromDate || 'Start'} - {toDate || 'End'}
        </Text>
      </View>

      {Array.isArray(data) && data.length > 0 ? (
        <View style={pdfStyles.table}>
          <View style={pdfStyles.tableRow}>
            <Text style={[pdfStyles.tableHeader, { width: '50%' }]}>Timestamp</Text>
            <Text style={[pdfStyles.tableHeader, { width: '50%' }]}>Value</Text>
          </View>
          {data.map((item, index) => (
            <View style={pdfStyles.tableRow} key={index}>
              <Text style={[pdfStyles.tableCell, { width: '50%' }]}>
                {item.timestamp ?? 'N/A'}
              </Text>
              <Text style={[pdfStyles.tableCell, { width: '50%' }]}>
                {item.value ?? 'N/A'}
              </Text>
            </View>
          ))}
        </View>
      ) : (
        <View style={pdfStyles.section}>
          <Text>No data available based on the filter.</Text>
        </View>
      )}
    </Page>
  </Document>
);

export default PDFDocument;
