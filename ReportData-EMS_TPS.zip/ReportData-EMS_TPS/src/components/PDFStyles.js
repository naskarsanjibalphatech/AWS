// PDFStyles.js
import { StyleSheet } from '@react-pdf/renderer';

const pdfStyles = StyleSheet.create({
  page: { padding: 30 },
  section: { marginBottom: 20 },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  filterText: {
    fontSize: 12,
    marginBottom: 10,
    textAlign: 'center',
  },
  table: {
    display: 'table',
    width: '100%',
    borderStyle: 'solid',
    borderWidth: 1,
    borderBottomWidth: 0,
  },
  tableRow: { margin: 'auto', flexDirection: 'row' },
  tableHeader: {
    backgroundColor: '#e9ecef',
    color: '#495057',
    padding: 8,
    fontSize: 12,
    fontWeight: 'bold',
    borderStyle: 'solid',
    borderWidth: 1,
    borderTopWidth: 0,
    borderLeftWidth: 0,
  },
  tableCell: {
    margin: 'auto',
    padding: 8,
    fontSize: 10,
    borderStyle: 'solid',
    borderWidth: 1,
    borderTopWidth: 0,
    borderLeftWidth: 0,
  },
});

export default pdfStyles;
