import React, { useState, useEffect, useCallback } from 'react';
import { Power, Square, RotateCcw, Wifi, WifiOff, Clock, Activity } from 'lucide-react';

const PLCDashboard = () => {
  const [outputStatus, setOutputStatus] = useState(null);
  const [deviceOnline, setDeviceOnline] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [buttonStates, setButtonStates] = useState({
    start: false,
    stop: false
  });

  const API_BASE = 'https://f40vig8f9f.execute-api.us-east-1.amazonaws.com';

  const fetchOutputStatus = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch(`${API_BASE}/Read/?address=0&last=1`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data && data.length > 0) {
        const latestData = data[0];
        setOutputStatus(latestData.value);
        setLastUpdate(latestData.timestamp);
        setDeviceOnline(true);
      } else {
        setDeviceOnline(false);
      }
    } catch (err) {
      setError(err.message);
      setDeviceOnline(false);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const sendCommand = async (address, value) => {
    try {
      const response = await fetch(`${API_BASE}/Write/?address=${address}&value=${value}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      // Refresh data after command
      setTimeout(() => fetchOutputStatus(), 500);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleStartButton = async () => {
    setButtonStates(prev => ({ ...prev, start: true }));
    
    try {
      // Send value=1
      await sendCommand(1001, 1);
      
      // Wait 30ms then send value=0
      setTimeout(async () => {
        await sendCommand(1001, 0);
        setButtonStates(prev => ({ ...prev, start: false }));
      }, 30);
    } catch (err) {
      setButtonStates(prev => ({ ...prev, start: false }));
    }
  };

  const handleStopButton = async () => {
    setButtonStates(prev => ({ ...prev, stop: true }));
    
    try {
      // Send value=1
      await sendCommand(1003, 1);
      
      // Wait 30ms then send value=0
      setTimeout(async () => {
        await sendCommand(1003, 0);
        setButtonStates(prev => ({ ...prev, stop: false }));
      }, 30);
    } catch (err) {
      setButtonStates(prev => ({ ...prev, stop: false }));
    }
  };

  const handleRefresh = () => {
    fetchOutputStatus();
  };

  useEffect(() => {
    fetchOutputStatus();
    
    // Auto-refresh every 10 seconds
    const interval = setInterval(fetchOutputStatus, 10000);
    
    return () => clearInterval(interval);
  }, [fetchOutputStatus]);

  const formatDateTime = (timestamp) => {
    if (!timestamp) return 'N/A';
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-blue-600/20 rounded-lg">
                <Activity className="h-8 w-8 text-blue-400" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">PLC Control Dashboard</h1>
                <p className="text-slate-400">Industrial Process Control Interface</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg border ${
                deviceOnline 
                  ? 'bg-green-600/20 border-green-600/30 text-green-400' 
                  : 'bg-red-600/20 border-red-600/30 text-red-400'
              }`}>
                {deviceOnline ? <Wifi className="h-5 w-5" /> : <WifiOff className="h-5 w-5" />}
                <span className="font-medium">{deviceOnline ? 'Online' : 'Offline'}</span>
              </div>
              
              <button
                onClick={handleRefresh}
                disabled={isLoading}
                className="flex items-center space-x-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg border border-slate-600 transition-colors"
              >
                <RotateCcw className={`h-5 w-5 ${isLoading ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Status Panel */}
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white">Output Status</h2>
              <div className="flex items-center space-x-2 text-slate-400">
                <Clock className="h-4 w-4" />
                <span className="text-sm">Last Update</span>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="text-center">
                <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full border-4 ${
                  outputStatus === 1 
                    ? 'bg-green-600/20 border-green-500 text-green-400' 
                    : 'bg-slate-700/50 border-slate-600 text-slate-400'
                } transition-all duration-300`}>
                  <div className="text-center">
                    <div className={`w-6 h-6 rounded-full mx-auto mb-2 ${
                      outputStatus === 1 ? 'bg-green-400 animate-pulse' : 'bg-slate-500'
                    }`}></div>
                    <span className="text-sm font-medium">
                      {outputStatus === 1 ? 'ON' : 'OFF'}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <div className="text-slate-400 text-sm mb-1">Output Value</div>
                  <div className="text-2xl font-bold text-white">
                    {outputStatus !== null ? outputStatus : '-'}
                  </div>
                </div>
                
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <div className="text-slate-400 text-sm mb-1">Address</div>
                  <div className="text-2xl font-bold text-white">0</div>
                </div>
              </div>
              
              <div className="bg-slate-700/50 rounded-lg p-4">
                <div className="text-slate-400 text-sm mb-1">Last Update Time</div>
                <div className="text-white font-medium">
                  {formatDateTime(lastUpdate)}
                </div>
              </div>
            </div>
          </div>

          {/* Control Panel */}
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white">Process Control</h2>
              <div className="text-slate-400 text-sm">Push Button Operations</div>
            </div>
            
            <div className="space-y-4">
              <button
                onClick={handleStartButton}
                disabled={buttonStates.start || !deviceOnline}
                className="w-full flex items-center justify-center space-x-3 px-6 py-4 bg-green-600 hover:bg-green-700 disabled:bg-green-600/50 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-all duration-200 transform hover:scale-105 active:scale-95"
              >
                <Power className="h-6 w-6" />
                <span className="text-lg">
                  {buttonStates.start ? 'START PRESSED' : 'START PROCESS'}
                </span>
              </button>
              
              <button
                onClick={handleStopButton}
                disabled={buttonStates.stop || !deviceOnline}
                className="w-full flex items-center justify-center space-x-3 px-6 py-4 bg-red-600 hover:bg-red-700 disabled:bg-red-600/50 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-all duration-200 transform hover:scale-105 active:scale-95"
              >
                <Square className="h-6 w-6" />
                <span className="text-lg">
                  {buttonStates.stop ? 'STOP PRESSED' : 'STOP PROCESS'}
                </span>
              </button>
              
              <div className="mt-6 p-4 bg-slate-700/50 rounded-lg">
                <h3 className="text-white font-medium mb-2">Control Information</h3>
                <div className="space-y-2 text-sm text-slate-400">
                  <div>• Start Button: Address 1001</div>
                  <div>• Stop Button: Address 1003</div>
                  <div>• Push button operation (30ms pulse)</div>
                  <div>• Auto-refresh every 10 seconds</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mt-6 bg-red-600/20 border border-red-600/30 rounded-xl p-4">
            <div className="flex items-center space-x-2 text-red-400">
              <div className="w-4 h-4 bg-red-500 rounded-full"></div>
              <span className="font-medium">Error: {error}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PLCDashboard;np