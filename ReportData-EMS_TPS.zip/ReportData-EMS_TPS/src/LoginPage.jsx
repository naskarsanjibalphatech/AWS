import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const LoginPage = ({ onLoginSuccess }) => {
  const navigate = useNavigate();
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // Credentials
  const SECRET_USER_ID = 'TPS';
  const SECRET_PASSWORD = 'TPS@123';

  const handleLogin = () => {
    if (userId === SECRET_USER_ID && password === SECRET_PASSWORD) {
      localStorage.setItem('isLoggedIn', 'true');
      setError('');
      onLoginSuccess();
      navigate('/', { replace: true }); // ✅ Redirect to dashboard root
    } else {
      setError('Invalid Credentials. Please try again.');
    }
  };

  const containerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
    backgroundColor: '#f4f6f8',
  };

  const formContainerStyle = {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    width: '400px',
    maxWidth: '90%',
  };

  const headingStyle = {
    textAlign: 'center',
    marginBottom: '25px',
    color: '#333',
    fontWeight: 'bold',
    fontSize: '24px',
  };

  const errorStyle = {
    color: '#d32f2f',
    marginBottom: '15px',
    textAlign: 'center',
  };

  const labelStyle = {
    display: 'block',
    marginBottom: '8px',
    color: '#555',
    fontWeight: '500',
  };

  const inputStyle = {
    width: '100%',
    padding: '12px',
    marginBottom: '20px',
    borderRadius: '4px',
    border: '1px solid #ccc',
    fontSize: '16px',
  };

  const buttonStyle = {
    backgroundColor: '#007bff',
    color: 'white',
    padding: '12px 20px',
    borderRadius: '4px',
    border: 'none',
    cursor: 'pointer',
    fontSize: '16px',
    width: '100%',
    fontWeight: '500',
    transition: 'background-color 0.3s ease',
  };

  const buttonHoverStyle = {
    backgroundColor: '#0056b3',
  };

  const handleMouseEnter = (e) => {
    e.target.style.backgroundColor = buttonHoverStyle.backgroundColor;
  };

  const handleMouseLeave = (e) => {
    e.target.style.backgroundColor = buttonStyle.backgroundColor;
  };

  return (
    <div style={containerStyle}>
      <div style={formContainerStyle}>
        <h2 style={headingStyle}>Login</h2>
        {error && <p style={errorStyle}>{error}</p>}
        <div>
          <label style={labelStyle}>User ID:</label>
          <input
            type="text"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            style={inputStyle}
          />
        </div>
        <div>
          <label style={labelStyle}>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={inputStyle}
          />
        </div>
        <button
          onClick={handleLogin}
          style={buttonStyle}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          Sign In
        </button>
      </div>
    </div>
  );
};

export default LoginPage;
