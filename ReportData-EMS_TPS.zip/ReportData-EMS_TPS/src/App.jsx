import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import LoginPage from './LoginPage';
import Home from './pages/home/Home';
import Container from './pages/home/Container';
import './styles/globals.css';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(localStorage.getItem('isLoggedIn') === 'true');

  useEffect(() => {
    const syncLogout = (e) => {
      if (e.key === 'isLoggedIn') {
        setIsLoggedIn(e.newValue === 'true');
      }
    };
    window.addEventListener('storage', syncLogout);
    return () => window.removeEventListener('storage', syncLogout);
  }, []);

  const handleLoginSuccess = () => {
    localStorage.setItem('isLoggedIn', 'true');
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    setIsLoggedIn(false);
  };

  return (
    <Router>
      <Routes>
        {/* Login route is always accessible */}
        <Route path="/login" element={<LoginPage onLoginSuccess={handleLoginSuccess} />} />

        {/* Protected Home route */}
       <Route
  path="/"
  element={isLoggedIn ? <Home onLogout={handleLogout} /> : <Navigate to="/login" replace />}
/>


        {/* Protected Meter 06 Dashboard, wrapped with Container */}
        <Route
  path="/meter06"
  element={
    isLoggedIn
      ? <Container onLogout={handleLogout} /> // ✅ Just render Container
      : <Navigate to="/login" replace />
  }
/>

        {/* Catch-all redirect */}
        <Route
          path="*"
          element={<Navigate to={isLoggedIn ? '/' : '/login'} replace />}
        />
      </Routes>
    </Router>
  );
}

export default App;
