import Container from "./Container";

const Index = ({ onLogout }) => {
  return <Container onLogout={onLogout} />;
};

export default Index;
