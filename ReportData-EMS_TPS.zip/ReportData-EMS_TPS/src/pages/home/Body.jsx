import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { generatePDF } from '../../utils/generatePDF';
import { generateExcel } from '../../utils/generateExcel'; // Add this import
import { useNavigate } from 'react-router-dom';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import {
  Wifi, WifiOff, RotateCcw, LogOut, Zap, Gauge, Clock, Battery, ArrowLeft, AlertCircle, Filter, Download, Share
} from 'lucide-react';
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Tooltip,
  Legend,
  Filler,
  Title,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Tooltip,
  Legend,
  Filler,
  Title
);

const ClientPaginationControls = ({ pagination, onPageChange, onLimitChange, showDateRange }) => {
  const { page, limit, total, totalPages } = pagination;
  if (total === 0) return null;
  const startEntry = (page - 1) * limit + 1;
  const endEntry = Math.min(page * limit, total);

  return (
    <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mt-4 px-6 py-4 bg-blue-50 border-t border-blue-200 rounded-b-xl">
      {/* Results Info */}
      <div className="text-sm text-blue-800 font-medium">
        {showDateRange && (
          <div className="text-xs text-blue-600 mb-1">
            📅 Showing paginated results for selected date or today's data
          </div>
        )}
        Displaying {startEntry} to {endEntry} of {total} total records
      </div>
      <div className="flex items-center gap-2">
        <span className="text-sm text-blue-700 font-medium">Records per page:</span>
        <select
          value={limit}
          onChange={(e) => onLimitChange(Number(e.target.value))}
          className="px-3 py-1 border border-blue-300 rounded-lg text-sm bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value={25}>25</option>
          <option value={50}>50</option>
          <option value={100}>100</option>
        </select>
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={() => onPageChange(1)}
          disabled={page === 1}
          className="px-3 py-1.5 text-sm bg-white border border-blue-300 rounded-lg hover:bg-blue-50 disabled:opacity-50"
        >⏮️ First</button>
        <button
          onClick={() => onPageChange(page - 1)}
          disabled={page === 1}
          className="px-3 py-1.5 text-sm bg-white border border-blue-300 rounded-lg hover:bg-blue-50 disabled:opacity-50"
        >◀️ Prev</button>
        <div className="flex gap-1">
          {(() => {
            const maxVisible = 5;
            let startPage, endPage;
            if (totalPages <= maxVisible) {
              startPage = 1;
              endPage = totalPages;
            } else {
              if (page <= 3) {
                startPage = 1;
                endPage = maxVisible;
              } else if (page > totalPages - 3) {
                startPage = totalPages - maxVisible + 1;
                endPage = totalPages;
              } else {
                startPage = page - 2;
                endPage = page + 2;
              }
            }
            const pages = [];
            for (let i = startPage; i <= endPage; i++) {
              pages.push(
                <button
                  key={i}
                  onClick={() => onPageChange(i)}
                  className={`px-3 py-1.5 text-sm border rounded-lg ${
                    i === page
                      ? 'bg-blue-600 text-white border-blue-600 font-bold'
                      : 'bg-white border-blue-300 hover:bg-blue-50 text-blue-700'
                  }`}
                >{i}</button>
              );
            }
            return pages;
          })()}
        </div>
        <button
          onClick={() => onPageChange(page + 1)}
          disabled={page === totalPages}
          className="px-3 py-1.5 text-sm bg-white border border-blue-300 rounded-lg hover:bg-blue-50 disabled:opacity-50"
        >Next ▶️</button>
        <button
          onClick={() => onPageChange(totalPages)}
          disabled={page === totalPages}
          className="px-3 py-1.5 text-sm bg-white border border-blue-300 rounded-lg hover:bg-blue-50 disabled:opacity-50"
        >Last ⏭️</button>
      </div>
    </div>
  );
};

const MetricCard = ({ title, value, unit, icon: Icon, isLoading, isAlert, showLastUpdate, lastUpdate }) => (
  <div className={`bg-white border rounded-xl p-6 shadow-sm ${isAlert ? 'border-red-300 bg-red-50 animate-pulse' : 'border-gray-200'}`}>
    <div className="flex items-center justify-between">
      <div>
        <p className={`text-sm font-medium ${isAlert ? 'text-red-700' : 'text-gray-600'}`}>
          {title}
          {isAlert && <span className="ml-2 text-red-500">⚠️</span>}
        </p>
        <p className={`text-2xl font-bold mt-1 ${isAlert ? 'text-red-900' : 'text-gray-900'}`}>
          {isLoading ? '...' : `${value} ${unit}`}
        </p>
        {showLastUpdate && (
          <div className="flex items-center text-xs text-gray-500 mt-2">
            <Clock className="h-3 w-3 mr-1" />
            <span>Updated: {lastUpdate}</span>
          </div>
        )}
      </div>
      <div className={`p-3 rounded-lg ${isAlert ? 'bg-red-100' : 'bg-gray-100'}`}>
        <Icon className={`h-6 w-6 ${isAlert ? 'text-red-600' : 'text-gray-600'}`} />
      </div>
    </div>
  </div>
);

const formatValueForDisplay = (value) => {
  return value === -404 ? 'N/A' : value;
};

const DataLogChart = React.memo(function DataLogChart({
  data = [],
  formatDateTime,
  selectedType,
}) {
  const chartData = React.useMemo(() => {
    if (!data.length) return { labels: [], datasets: [] };

    if (selectedType === 'all') {
      const consumptionData = data.filter(row => row.address === 30128);
      const totalLoadData = data.filter(row => row.address === 30080);
      const phase1Data = data.filter(row => row.address === 30066);
      const phase2Data = data.filter(row => row.address === 30068);
      const phase3Data = data.filter(row => row.address === 30070);

      const allTimestamps = [...new Set(data.map(row => row.timestamp))]
        .sort((a, b) => new Date(a) - new Date(b));
      const labels = allTimestamps.map(ts => formatDateTime(ts));
      const createValueArray = (dataArray, timestamps) =>
        timestamps.map(ts => {
          const item = dataArray.find(row => row.timestamp === ts);
          return item && item.value !== -404 ? Number(item.value) : null;
        });
      return {
        labels,
        datasets: [
          {
            label: 'Total Consumption (kWh)',
            data: createValueArray(consumptionData, allTimestamps),
            borderColor: '#f029a1ff',
            backgroundColor: '#FF6B6B33',
            pointBackgroundColor: '#FF6B6B',
            tension: 0.3,
            fill: false,
            spanGaps: true,
            yAxisID: 'y1',
          },
          {
            label: 'Total Load (kW)',
            data: createValueArray(totalLoadData, allTimestamps),
            borderColor: '#4ECDC4',
            backgroundColor: '#4ECDC433',
            pointBackgroundColor: '#4ECDC4',
            tension: 0.3,
            fill: false,
            spanGaps: true,
            yAxisID: 'y',
          },
          {
            label: 'Phase 1 Load (kW)',
            data: createValueArray(phase1Data, allTimestamps),
            borderColor: '#FF0000',
            backgroundColor: '#FF000033',
            pointBackgroundColor: '#FF0000',
            tension: 0.3,
            fill: false,
            spanGaps: true,
            yAxisID: 'y',
          },
          {
            label: 'Phase 2 Load (kW)',
            data: createValueArray(phase2Data, allTimestamps),
            borderColor: '#f68e06ff',
            backgroundColor: '#FFFF0033',
            pointBackgroundColor: '#ff9500ff',
            tension: 0.3,
            fill: false,
            spanGaps: true,
            yAxisID: 'y',
          },
          {
            label: 'Phase 3 Load (kW)',
            data: createValueArray(phase3Data, allTimestamps),
            borderColor: '#0000FF',
            backgroundColor: '#0000FF33',
            pointBackgroundColor: '#0000FF',
            tension: 0.3,
            fill: false,
            spanGaps: true,
            yAxisID: 'y',
          }
        ]
      };
    } else {
      const labels = data.map(row => formatDateTime(row.timestamp)).reverse();
      const values = data.map(row => {
        const cleanVal = row.value === -404 ? null : Number(row.value);
        return isNaN(cleanVal) ? null : cleanVal;
      }).reverse();
      const unit = data[0]?.unit || '';
      const colors = {
        net_energy: '#f029a1ff',
        total_power: '#4ECDC4',
        phase1_power: '#FF0000',
        phase2_power: '#ff9100ff',
        phase3_power: '#0000FF',
      };
      const base = colors[selectedType] || '#6366F1';
      return {
        labels,
        datasets: [{
          label: `Value (${unit})`,
          data: values,
          borderColor: base,
          backgroundColor: base + '33',
          pointBackgroundColor: base,
          pointBorderColor: base,
          tension: 0.3,
          fill: true,
          spanGaps: true,
        }]
      };
    }
  }, [data, formatDateTime, selectedType]);

  if (!chartData.labels.length) {
    return (
      <div className="text-center text-sm text-gray-400 mt-6">
        No data to plot
      </div>
    );
  }

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      tooltip: {
        mode: 'index', intersect: false,
        callbacks: {
          label: context => {
            const label = context.dataset.label || '';
            const value = context.parsed.y;
            return value !== null ? `${label}: ${value}` : `${label}: N/A`;
          }
        }
      },
      legend: { display: true, position: 'top' },
      title: {
        display: true,
        text: selectedType === 'all'
          ? 'Energy & Load Data (Multi-Phase View) - Current Page'
          : selectedType === 'net_energy'
            ? 'Total Consumption Over Time - Current Page'
            : selectedType === 'total_power'
              ? 'Total Load Over Time - Current Page'
              : selectedType.includes('phase')
                ? `${selectedType.replace('_', ' ').replace('power', 'Load')} Over Time - Current Page`
                : 'Energy Data Over Time - Current Page',
      },
    },
    scales: selectedType === 'all' ? {
      x: {
        ticks: {
          maxRotation: 45,
          minRotation: 45,
          color: '#374151',
          autoSkip: true,
          maxTicksLimit: 15,
        },
        grid: { display: false },
      },
      y: {
        type: 'linear',
        display: true,
        position: 'left',
        title: { display: true, text: 'Load (kW)', color: '#10B981' },
        ticks: { color: '#10B981' },
        grid: { color: '#E5E7EB' },
      },
      y1: {
        type: 'linear',
        display: true,
        position: 'right',
        title: { display: true, text: 'Consumption (kWh)', color: '#3B82F6' },
        ticks: { color: '#3B82F6' },
        grid: { drawOnChartArea: false },
      }
    } : {
      y: { ticks: { color: '#374151' }, grid: { color: '#E5E7EB' } },
      x: {
        ticks: {
          maxRotation: 45,
          minRotation: 45,
          color: '#374151',
          autoSkip: true,
          maxTicksLimit: 15
        },
        grid: { display: false }
      }
    }
  };

  return (
    <div className="w-full h-72 mt-8">
      <Line data={chartData} options={options} />
    </div>
  );
});

const Body = ({
  deviceOnline = false,
  currentData = { netKwh: 0, totalKw: 0, phase1Kw: 0, phase2Kw: 0, phase3Kw: 0, lastUpdate: null },
  dataLog = [],
  isLoading = false,
  error,
  thresholds = {},
  fetchThresholds,
  setThresholds,
  selectedType,
  setSelectedType,
  lastEntries,
  setLastEntries,
  downloadReport,
  shareData,
  formatDateTime = () => 'N/A',
  whatsappContact,
  setWhatsappContact,
  showContactForm,
  setShowContactForm,
  contacts = [],
  setContacts,
  fetchCurrentData,
  fetchDataLog,
  CONTACTS_API,
  onLogout,
  CONTACTS_ID,
  userName,
  setUserName,
  savedThresholds,
  thresholdInputs,
  setThresholdInputs,
  clientPagination,
  onClientPageChange,
  onClientLimitChange,
  allFilteredData,
  alertLog,
  allFilteredAlertData,
  alertSelectedDate,
  setAlertSelectedDate,
  alertDateMode,
  setAlertDateMode,
  alertPagination,
  onAlertPageChange,
  onAlertLimitChange,
  fetchAlertLog,
  selectedDate,
  setSelectedDate,
  dateMode,
  setDateMode,
}) => {
  const [alertFlags, setAlertFlags] = React.useState({'30080': false, '30128': false});
  const [isEditingUser, setIsEditingUser] = React.useState(false);
  const [tempUserName, setTempUserName] = React.useState(userName);

  const handleRefresh = () => {
    fetchCurrentData();
    fetchDataLog();
    fetchThresholds();
  };

  const navigate = useNavigate();
  const goBackHome = () => { navigate('/'); };
  const handleUserNameChange = (value) => { setTempUserName(value); };

  const handleUserSubmit = async () => {
    try {
      await fetch(CONTACTS_API, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: 'user', value: tempUserName }),
      });
      setUserName(tempUserName);
      setIsEditingUser(false);
      alert('User name updated successfully!');
    } catch {
      alert('Failed to update user name');
    }
  };

  const handleUserCancel = () => {
    setTempUserName(userName);
    setIsEditingUser(false);
  };

  const safeDataLog = Array.isArray(dataLog) ? dataLog : [];

  React.useEffect(() => {
    setTempUserName(userName);
  }, [userName]);

  React.useEffect(() => {
    const ALERT_API_URL = 'https://sutvxawqza.execute-api.us-east-1.amazonaws.com/Trigger/';
    const newFlags = { ...alertFlags };
    const energyValue = currentData?.netKwh;
    const loadValue = currentData?.totalKw;
    const rawEnergyThreshold = savedThresholds?.['30128'];
    const rawLoadThreshold = savedThresholds?.['30080'];

    if (
      energyValue == null || loadValue == null ||
      rawEnergyThreshold == null || rawLoadThreshold == null
    ) return;

    const energyThreshold = parseFloat(rawEnergyThreshold);
    const loadThreshold = parseFloat(rawLoadThreshold);
    if (isNaN(energyThreshold) || isNaN(loadThreshold)) return;

    const shouldTriggerEnergyAlert = energyValue > energyThreshold && energyValue > 0;
    const shouldTriggerLoadAlert = loadValue > loadThreshold && loadValue > 0;

    const handleTrigger = async (type) => {
      try { await fetch(ALERT_API_URL, { method: 'POST' }); } catch {}
    };

    if (shouldTriggerEnergyAlert && !alertFlags['30128']) {
      handleTrigger('energy');
      newFlags['30128'] = true;
    } else if (!shouldTriggerEnergyAlert && alertFlags['30128']) {
      handleTrigger('energy-recovery');
      newFlags['30128'] = false;
    }
    if (shouldTriggerLoadAlert && !alertFlags['30080']) {
      handleTrigger('load');
      newFlags['30080'] = true;
    } else if (!shouldTriggerLoadAlert && alertFlags['30080']) {
      handleTrigger('load-recovery');
      newFlags['30080'] = false;
    }
    if (newFlags['30128'] !== alertFlags['30128'] || newFlags['30080'] !== alertFlags['30080']) {
      setAlertFlags(newFlags);
    }
  }, [currentData, savedThresholds]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* HEADER */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row justify-between items-center">
          <div className="flex items-center space-x-4">
            <div className="p-2 bg-blue-600 rounded-lg">
              <Zap className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Energy Management System</h1>
              <p className="text-sm text-gray-500">TPS Real Estate Pvt Ltd</p>
              <div className="flex items-center gap-2 text-sm text-gray-700 mt-1">
                <span className="font-medium">Meter No:</span> 43240123 &nbsp;|&nbsp;
                <div className="flex items-center gap-2 sm:gap-4">
                  {!isEditingUser ? (
                    <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                      <div className="flex items-center gap-1 sm:gap-2 min-w-0">
                        <div className="min-w-0">
                          <span className="font-medium text-gray-700">User: </span>
                          <span className="text-gray-900 font-medium">{userName || 'Unnamed User'}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => setIsEditingUser(true)}
                        className="p-1.5 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg"
                        title="Edit user name"
                      >
                        <span className="text-sm">✏️</span>
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 sm:gap-3">
                      <div className="flex items-center gap-1 sm:gap-2 min-w-0">
                        <span className="text-base flex-shrink-0">👤</span>
                        <div className="min-w-0">
                          <p className="text-xs text-gray-600">User</p>
                          <input
                            type="text"
                            value={tempUserName}
                            onChange={e => handleUserNameChange(e.target.value)}
                            placeholder="Enter user name"
                            className="w-[140px] px-2 py-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                            autoFocus
                          />
                        </div>
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <button
                          onClick={handleUserSubmit}
                          className="px-2 py-1 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm font-medium shadow-sm"
                          title="Save name"
                        >✓</button>
                        <button
                          onClick={handleUserCancel}
                          className="px-2 py-1 bg-gray-600 text-white rounded-lg hover:bg-gray-700 text-sm font-medium shadow-sm"
                          title="Cancel"
                        >✕</button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2 sm:space-x-4 mt-4 sm:mt-0">
            <div className={`flex items-center space-x-2 px-3 py-1.5 rounded-full text-sm font-medium ${
              deviceOnline ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              {deviceOnline ? <Wifi className="h-4 w-4" /> : <WifiOff className="h-4 w-4" />}
              <span className="hidden sm:inline">{deviceOnline ? 'Online' : 'Offline'}</span>
            </div>
            <button
              onClick={handleRefresh}
              disabled={isLoading}
              className="flex items-center space-x-2 px-3 py-1.5 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
            >
              <RotateCcw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Refresh</span>
            </button>
            <button onClick={goBackHome}
              className="flex items-center space-x-2 px-3 py-1.5 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              <ArrowLeft className="h-4 w-4" />
              <span className="hidden sm:inline">Home</span>
            </button>
            <button
              onClick={onLogout}
              className="flex items-center space-x-2 px-3 py-1.5 text-sm text-gray-700 hover:text-gray-900 hover:bg-gray-100 rounded-lg"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </header>
      {/* MAIN */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-center space-x-3">
              <AlertCircle className="h-5 w-5 text-red-600" />
              <div>
                <h3 className="text-sm font-medium text-red-800">System Error</h3>
                <p className="text-sm text-red-700 mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}
        {/* STATUS */}
        <section className="mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">System Status</h2>
          {/* First Row - Main Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
            <MetricCard
              title="TOTAL CONSUMPTION"
              value={formatValueForDisplay(currentData.netKwh)}
              unit="kWh"
              icon={Battery}
              isLoading={isLoading}
              isAlert={currentData.netKwh > (parseFloat(savedThresholds?.['30128']) || 0)}
              showLastUpdate={true}
              lastUpdate={formatDateTime(currentData.lastUpdate)}
            />
            <MetricCard
              title="TOTAL LOAD"
              value={formatValueForDisplay(currentData.totalKw)}
              unit="kW"
              icon={Gauge}
              isLoading={isLoading}
              isAlert={currentData.totalKw > (parseFloat(savedThresholds?.['30080']) || 0)}
            />
            <MetricCard
              title="STATUS"
              value={deviceOnline ? 'Online' : 'Offline'}
              icon={deviceOnline ? Wifi : WifiOff}
              unit=""
              isLoading={isLoading}
              isAlert={!deviceOnline}
              showLastUpdate={true}
              lastUpdate={formatDateTime(currentData.deviceCheckTime)}
            />
          </div>
          {/* Second Row - Phase Loads */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <MetricCard title="PHASE 1 LOAD" value={formatValueForDisplay(currentData.phase1Kw)} unit="kW" icon={Zap} isLoading={isLoading} isAlert={false} />
            <MetricCard title="PHASE 2 LOAD" value={formatValueForDisplay(currentData.phase2Kw)} unit="kW" icon={Zap} isLoading={isLoading} isAlert={false} />
            <MetricCard title="PHASE 3 LOAD" value={formatValueForDisplay(currentData.phase3Kw)} unit="kW" icon={Zap} isLoading={isLoading} isAlert={false} />
          </div>
        </section>
        {/* THRESHOLDS */}
        <section className="mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Alert Threshold Settings</h2>
          <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm space-y-6">
            {[
              { address: '30080', label: 'Set Upper Limit For Load (KW)' },
              { address: '30128', label: 'Set Upper Limit For Units Consumed (KWh)' }
            ].map(({ address, label }) => (
              <div key={address} className="border-b border-gray-100 pb-4 last:border-b-0 last:pb-0">
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
                  <div className="sm:col-span-4">
                    <label className="text-sm font-medium text-gray-700">{label}</label>
                    <div className="mt-1 text-xs text-gray-500">
                      Last Updated Value: <span className="font-medium text-gray-700">{savedThresholds[address] || 'Not set'}</span>
                    </div>
                  </div>
                  <div className="sm:col-span-4">
                    <input
                      type="number"
                      value={thresholdInputs[address] || ''}
                      onChange={e =>
                        setThresholdInputs(prev => ({
                          ...prev,
                          [address]: e.target.value,
                        }))
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Enter new threshold"
                    />
                  </div>
                  <div className="sm:col-span-4 flex justify-end">
                    <button
                      onClick={async () => {
                        const value = thresholdInputs[address]?.trim();
                        if (!value || isNaN(Number(value))) return alert('Enter valid number');
                        try {
                          await fetch(CONTACTS_API, {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ id: address, value }),
                          });
                          alert(`Threshold for address ${address} updated!`);
                          if (typeof fetchThresholds === 'function') {
                            fetchThresholds();
                          }
                        } catch (err) {
                          alert('Update failed. Try again.');
                        }
                      }}
                      className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
                    >Update</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
{/* DATA LOG */}
<section className="mb-8">
  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
    <h2 className="text-lg font-semibold text-gray-900">Data Log</h2>
    <div className="flex flex-wrap items-center gap-3">
      <div className="flex items-center space-x-2 bg-white border border-gray-200 rounded-lg p-2">
        <span className="text-sm text-gray-500">Search By:</span>
        <select 
          value={dateMode} 
          onChange={e => {
            setDateMode(e.target.value);
            if (e.target.value === 'today') setSelectedDate(null);
          }} 
          className="text-sm bg-transparent border-none focus:outline-none text-gray-700"
        >
          <option value="today">Today (Last 24hrs)</option>
          <option value="custom">Select Date</option>
          <option value="entries">Last Entries</option>
        </select>
      </div>

      {dateMode === 'custom' && (
        <div className="flex items-center space-x-2 bg-white border border-gray-200 rounded-lg p-2">
          <span className="text-sm text-gray-500">Date:</span>
          <DatePicker
            selected={selectedDate}
            onChange={date => setSelectedDate(date)}
            dateFormat="yyyy-MM-dd"
            className="text-sm bg-transparent focus:outline-none text-gray-700 w-28"
            placeholderText="Select Date"
            isClearable
            maxDate={new Date()}
          />
        </div>
      )}

      <div className="flex items-center space-x-2 bg-white border border-gray-200 rounded-lg p-2">
        <Filter className="h-4 w-4 text-gray-500" />
        <select value={selectedType} onChange={e => setSelectedType(e.target.value)} className="text-sm bg-transparent border-none focus:outline-none text-gray-700">
          <option value="all">All Types</option>
          <option value="net_energy">Total Consumption</option>
          <option value="total_power">Total Load</option>
          <option value="phase1_power">Phase 1 Load</option>
          <option value="phase2_power">Phase 2 Load</option>
          <option value="phase3_power">Phase 3 Load</option>
        </select>
      </div>

      {dateMode === 'entries' && (
        <div className="flex items-center space-x-2 bg-white border border-gray-200 rounded-lg p-2">
          <span className="text-sm text-gray-500">Last</span>
          <select value={lastEntries} onChange={e => setLastEntries(Number(e.target.value))} className="text-sm bg-transparent border-none focus:outline-none text-gray-700">
            {[5, 10, 20, 50, 100].map(n => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
          <span className="text-sm text-gray-500">entries</span>
        </div>
      )}

      {(dateMode === 'today' || (dateMode === 'custom' && selectedDate)) && allFilteredData && allFilteredData.length > 50 && (
        <div className="flex items-center space-x-2 bg-white border border-gray-200 rounded-lg p-2">
          <span className="text-sm text-gray-500">Export:</span>
          <select id="exportType" className="text-sm bg-transparent border-none focus:outline-none text-gray-700">
            <option value="all">All {allFilteredData.length} Records</option>
            <option value="current">Current Page ({safeDataLog.length} Records)</option>
          </select>
        </div>
      )}

     {/* Replace the existing download button section with this */}
<div className="flex items-center gap-2">
  <button
    onClick={() => {
      const now = new Date();
      const generatedAt = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      const exportTypeSelect = document.getElementById('exportType');
      const exportAll = !exportTypeSelect || exportTypeSelect.value === 'all';
      let dataToExport;
      if ((dateMode === 'today' || (dateMode === 'custom' && selectedDate)) && allFilteredData && allFilteredData.length > 0) {
        dataToExport = exportAll ? allFilteredData : safeDataLog;
      } else {
        dataToExport = safeDataLog;
      }
      const processedData = dataToExport.map(row => ({
        ...row,
        value: formatValueForDisplay(row.value)
      }));
      let dateRangeInfo = {};
      if (dateMode === 'today') {
        const now = new Date();
        const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        dateRangeInfo = { fromDate: yesterday, toDate: now };
      } else if (dateMode === 'custom' && selectedDate) {
        const startOfDay = new Date(selectedDate);
        startOfDay.setHours(0, 1, 0, 0);
        const endOfDay = new Date(selectedDate);
        endOfDay.setHours(23, 59, 59, 999);
        dateRangeInfo = { fromDate: startOfDay, toDate: endOfDay };
      }
      generatePDF({
        dataLog: processedData,
        generatedAt,
        meterName: selectedType === 'net_energy' ? 'Meter 06' : 'Meter 07',
        fromDate: dateRangeInfo.fromDate,
        toDate: dateRangeInfo.toDate,
        lastEntries: processedData.length,
        userName,
      });
    }}
    className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2.5 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center justify-center border-0 cursor-pointer"
  >
    <Download className="w-4 h-4 mr-2" />
    Download PDF
  </button>

  <button
    onClick={() => {
      const now = new Date();
      const generatedAt = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      const exportTypeSelect = document.getElementById('exportType');
      const exportAll = !exportTypeSelect || exportTypeSelect.value === 'all';
      let dataToExport;
      if ((dateMode === 'today' || (dateMode === 'custom' && selectedDate)) && allFilteredData && allFilteredData.length > 0) {
        dataToExport = exportAll ? allFilteredData : safeDataLog;
      } else {
        dataToExport = safeDataLog;
      }
      const processedData = dataToExport.map(row => ({
        ...row,
        value: formatValueForDisplay(row.value)
      }));
      let dateRangeInfo = {};
      if (dateMode === 'today') {
        const now = new Date();
        const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        dateRangeInfo = { fromDate: yesterday, toDate: now };
      } else if (dateMode === 'custom' && selectedDate) {
        const startOfDay = new Date(selectedDate);
        startOfDay.setHours(0, 1, 0, 0);
        const endOfDay = new Date(selectedDate);
        endOfDay.setHours(23, 59, 59, 999);
        dateRangeInfo = { fromDate: startOfDay, toDate: endOfDay };
      }
      generateExcel({
        dataLog: processedData,
        generatedAt,
        meterName: selectedType === 'net_energy' ? 'Meter 06' : 'Meter 07',
        fromDate: dateRangeInfo.fromDate,
        toDate: dateRangeInfo.toDate,
        lastEntries: processedData.length,
        userName,
      });
    }}
    className="bg-green-600 hover:bg-green-700 text-white font-medium px-6 py-2.5 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center justify-center border-0 cursor-pointer"
  >
    <Download className="w-4 h-4 mr-2" />
    Download Excel
  </button>
</div>

    </div>
  </div>

  {/* Date Range Info Banner */}
  {(dateMode === 'today' || (dateMode === 'custom' && selectedDate)) && allFilteredData && allFilteredData.length > 0 && (
    <div className="mb-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
      <div className="flex items-center gap-2 text-blue-800">
        <span className="text-lg">📊</span>
        <div>
          <p className="font-medium">
            {dateMode === 'today' ? "Today's Data (Last 24 Hours)" : `Selected Date: ${selectedDate?.toLocaleDateString()}`}
          </p>
          <p className="text-sm">
            {dateMode === 'today'
              ? `From: ${new Date(Date.now() - 24 * 60 * 60 * 1000).toLocaleString()} | To: ${new Date().toLocaleString()}`
              : selectedDate
                ? `Full day data from 00:01 AM to 11:59 PM on ${selectedDate.toLocaleDateString()}`
                : ''
            }
          </p>
          <p className="text-xs mt-1">
            Total Records Found: <span className="font-bold">{allFilteredData?.length || 0}</span>
            &nbsp;|&nbsp;
            Showing: <span className="font-bold">{safeDataLog?.length || 0}</span> per page
          </p>
        </div>
      </div>
    </div>
  )}

  <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-bold text-black uppercase tracking-wider">ID</th>
            <th className="px-6 py-3 text-left text-xs font-bold text-black uppercase tracking-wider">Timestamp</th>
            <th className="px-6 py-3 text-left text-xs font-bold text-black uppercase tracking-wider">Type</th>
            <th className="px-6 py-3 text-left text-xs font-bold text-black uppercase tracking-wider">Value</th>
            <th className="px-6 py-3 text-left text-xs font-bold text-black uppercase tracking-wider">Unit</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {safeDataLog.length ? safeDataLog.map((row) => (
            <tr key={row.id} className="hover:bg-gray-50 transition">
              <td className="px-6 py-4">{row.id}</td>
              <td className="px-6 py-4">{formatDateTime(row.timestamp)}</td>
              <td className="px-6 py-4 font-medium">{row.type}</td>
              <td className="px-6 py-4 font-bold">{formatValueForDisplay(row.value)}</td>
              <td className="px-6 py-4">{row.unit}</td>
            </tr>
          )) : (
            <tr>
              <td colSpan={5} className="px-6 py-8 text-center text-sm text-gray-500">
                {isLoading ? 'Loading data...' : 'No data available'}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>

    {(dateMode === 'today' || (dateMode === 'custom' && selectedDate)) && allFilteredData && allFilteredData.length > 0 && clientPagination && (
      <ClientPaginationControls
        pagination={clientPagination}
        onPageChange={onClientPageChange}
        onLimitChange={onClientLimitChange}
        showDateRange={true}
      />
    )}
  </div>

  <DataLogChart
    data={safeDataLog}
    formatDateTime={formatDateTime}
    selectedType={selectedType}
  />
</section>
{/* Alert Data Log Section */}
<div className="bg-white rounded-lg shadow-md p-6 mb-6">
  <h2 className="text-xl font-semibold mb-4 flex items-center">
    <AlertTriangle className="mr-2 text-red-500" />
    Alert Log
  </h2>
  
  {/* Alert Date Filter Controls */}
  <div className="mb-4 space-y-3">
    <div className="flex flex-wrap gap-2">
      <button
        onClick={() => setAlertDateMode('today')}
        className={`px-4 py-2 rounded ${
          alertDateMode === 'today'
            ? 'bg-blue-500 text-white'
            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
        }`}
      >
        Today's Alerts (Last 24 Hours)
      </button>
      <button
        onClick={() => setAlertDateMode('custom')}
        className={`px-4 py-2 rounded ${
          alertDateMode === 'custom'
            ? 'bg-blue-500 text-white'
            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
        }`}
      >
        Select Date
      </button>
    </div>
    
    {alertDateMode === 'custom' && (
      <div className="flex items-center gap-2">
        <label className="text-sm text-gray-600">Select Date:</label>
        <input
          type="date"
          value={alertSelectedDate ? alertSelectedDate.toISOString().split('T')[0] : ''}
          onChange={(e) => {
            if (e.target.value) {
              setAlertSelectedDate(new Date(e.target.value));
            } else {
              setAlertSelectedDate(null);
            }
          }}
          className="px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={fetchAlertLog}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Load Alerts
        </button>
      </div>
    )}
  </div>

  {/* Alert Date Range Display */}
  <div className="mb-3 text-sm text-gray-600 bg-gray-50 p-3 rounded">
    <strong>
      {alertDateMode === 'today' 
        ? "Today's Alerts (Last 24 Hours)" 
        : `Selected Date: ${alertSelectedDate?.toLocaleDateString()}`
      }
    </strong>
    <br />
    {alertDateMode === 'today' 
      ? `From: ${new Date(Date.now() - 24 * 60 * 60 * 1000).toLocaleString()} | To: ${new Date().toLocaleString()}`
      : alertSelectedDate 
        ? `Alert data from ${new Date(alertSelectedDate.getTime() - 24 * 60 * 60 * 1000).toLocaleDateString()} 00:00 AM to ${alertSelectedDate.toLocaleDateString()} 11:59 PM`
        : ''
    }
  </div>

  {/* Alert Records Summary */}
  <div className="mb-4 text-sm text-gray-600">
    <strong>Total Alert Records Found:</strong> {allFilteredAlertData?.length || 0} | 
    <strong> Showing:</strong> {alertLog?.length || 0} per page
  </div>

  {/* Alert Data Table */}
  <div className="overflow-x-auto">
    <table className="min-w-full table-auto border-collapse">
      <thead>
        <tr className="bg-gray-100">
          <th className="border border-gray-300 px-4 py-2 text-left">ID</th>
          <th className="border border-gray-300 px-4 py-2 text-left">Timestamp</th>
          <th className="border border-gray-300 px-4 py-2 text-left">Alert Type</th>
          
          
          <th className="border border-gray-300 px-4 py-2 text-left">Value</th>
        </tr>
      </thead>
      <tbody>
        {alertLog && alertLog.length > 0 ? (
          alertLog.map((row) => (
            <tr key={`alert-${row.id}`} className="hover:bg-gray-50">
              <td className="border border-gray-300 px-4 py-2">{row.id}</td>
              <td className="border border-gray-300 px-4 py-2">
                {formatDateTime(row.timestamp)}
              </td>
              <td className="border border-gray-300 px-4 py-2">{row.type}</td>
              <td className="border border-gray-300 px-4 py-2">{row.message}</td>
              <td className="border border-gray-300 px-4 py-2">
                <span className={`px-2 py-1 rounded text-xs ${
                  row.severity === 'High' || row.severity === 'Critical' 
                    ? 'bg-red-100 text-red-800' 
                    : row.severity === 'Medium' 
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'bg-green-100 text-green-800'
                }`}>
                  {row.severity}
                </span>
              </td>
              <td className="border border-gray-300 px-4 py-2">{row.value}</td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan="6" className="border border-gray-300 px-4 py-8 text-center text-gray-500">
              {isLoading ? 'Loading alerts...' : 'No alerts found for selected period'}
            </td>
          </tr>
        )}
      </tbody>
    </table>
  </div>

  {/* Alert Pagination Controls */}
  {alertPagination.totalPages > 1 && (
    <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
      <div className="flex items-center gap-2">
        <span className="text-sm text-gray-600">Show:</span>
        <select
          value={alertPagination.limit}
          onChange={(e) => onAlertLimitChange(Number(e.target.value))}
          className="px-3 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value={25}>25</option>
          <option value={50}>50</option>
          <option value={100}>100</option>
        </select>
        <span className="text-sm text-gray-600">alerts per page</span>
      </div>
      
      <div className="flex items-center gap-2">
        <button
          onClick={() => onAlertPageChange(alertPagination.page - 1)}
          disabled={alertPagination.page === 1}
          className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Previous
        </button>
        
        <span className="text-sm text-gray-600">
          Page {alertPagination.page} of {alertPagination.totalPages} 
          ({alertPagination.total} total alerts)
        </span>
        
        <button
          onClick={() => onAlertPageChange(alertPagination.page + 1)}
          disabled={alertPagination.page === alertPagination.totalPages}
          className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Next
        </button>
      </div>
    </div>
  )}
</div>


        {/* WHATSAPP CONTACTS */}
        <section className="mb-8 bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">WhatsApp Contacts</h3>
          <table className="min-w-full text-sm border border-gray-200 rounded">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left">#</th>
                <th className="px-4 py-2 text-left">Phone Number</th>
                <th className="px-4 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {contacts.map((contact, index) => (
                <tr key={index} className="border-t">
                  <td className="px-4 py-2">{index + 1}</td>
                  <td className="px-4 py-2">
                    <input
                      type="text"
                      value={contact}
                      onChange={e => {
                        const updated = [...contacts];
                        updated[index] = e.target.value;
                        setContacts(updated);
                      }}
                      className="w-full px-2 py-1 border border-gray-300 rounded"
                    />
                  </td>
                  <td className="px-4 py-2">
                    <button
                      onClick={() => {
                        const updated = contacts.filter((_, i) => i !== index);
                        setContacts(updated);
                      }}
                      className="text-red-600 hover:text-red-800 text-xs"
                    >Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-4 flex gap-3">
            <button onClick={() => setContacts([...contacts, ''])} className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">+ Add Number</button>
            <button
              onClick={async () => {
                const cleaned = contacts.map(c => c.trim()).filter(Boolean);
                try {
                  await fetch(CONTACTS_API, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: CONTACTS_ID, value: cleaned.join(',') }),
                  });
                  setContacts(cleaned);
                  alert('Contacts updated successfully!');
                } catch (err) {
                  alert('Failed to update contacts.');
                }
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >Save Changes</button>
          </div>
        </section>
      </main>
      {/* FOOTER */}
      <footer className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center">
          <p className="text-gray-600 text-sm">
            © 2025 &nbsp;
            <a href="https://www.alphatechsolutions.in" target="_blank" rel="noopener noreferrer" className="font-semibold text-blue-600 hover:underline">
              Alphatechsolutions.in
            </a>
            &nbsp;– Developed by Alphatech Solutions.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Body;
