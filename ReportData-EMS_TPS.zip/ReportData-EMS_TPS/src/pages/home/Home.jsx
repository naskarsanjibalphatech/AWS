import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Zap, LogOut } from 'lucide-react';

const Home = ({ onLogout }) => {
  const navigate = useNavigate();
  const [userName, setUserName] = useState('');

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await fetch('https://531s5b8fy6.execute-api.us-east-1.amazonaws.com/UserUpdate_TPS/?id=user');
        const data = await response.json();
        setUserName(data.value); // ✅ updated to match your API
      } catch (error) {
        console.error('Failed to fetch user info:', error);
      }
    };

    fetchUserData();
  }, []);

  const handleMeterClick = (id) => {
    if (id === '06') navigate('/meter06');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* HEADER */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row justify-between items-center">
          <div className="flex items-center space-x-4">
            <div className="p-2 bg-blue-600 rounded-lg">
              <Zap className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Energy Management System</h1>
              <p className="text-sm text-gray-500">TPS Real Estate Pvt Ltd</p>
            </div>
          </div>

          <button
            onClick={onLogout}
            className="flex items-center space-x-2 px-3 py-1.5 text-sm text-gray-700 hover:text-gray-900 hover:bg-gray-100 rounded-lg"
          >
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </header>

      {/* MAIN CONTENT */}
      <main className="flex-grow flex flex-col items-center justify-center py-10">
        <div className="mb-10 flex items-center space-x-4">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Zap className="h-6 w-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800">Select a Meter</h1>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6">
          {Array.from({ length: 10 }, (_, i) => {
            const id = String(i + 1).padStart(2, '0');
            const isMeter06 = id === '06';

            return (
              <button
                key={id}
                onClick={() => handleMeterClick(id)}
                className={`w-32 h-24 flex flex-col items-center justify-center text-lg font-medium border rounded-xl shadow-sm transition hover:shadow-md
                  ${
                    isMeter06
                      ? 'bg-blue-600 text-white hover:bg-blue-700 cursor-pointer'
                      : 'bg-white text-gray-400 border-gray-300 cursor-not-allowed'
                  }
                `}
                disabled={!isMeter06}
              >
                <span>Meter {id}</span>
                {isMeter06 && userName && (
                  <span className="text-xs mt-1 text-white">{userName}</span>
                )}
              </button>
            );
          })}
        </div>
      </main>

      {/* FOOTER */}
      <footer className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center">
          <p className="text-gray-600 text-sm">
            © 2025 &nbsp;
            <a
              href="https://www.alphatechsolutions.in"
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold text-blue-600 hover:underline"
            >
              Alphatechsolutions.in
            </a>
            &nbsp;– Developed by Alphatech Solutions.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Home;
