import React, { useState, useEffect, useCallback } from 'react';
import Body from './Body';

import {
  Wifi,
  WifiOff,
} from 'lucide-react';

const ADDRESSES = {
  NET_KWH: 30128,
  TOTAL_KW: 30080,
  PHASE1_KW: 30066,
  PHASE2_KW: 30068,
  PHASE3_KW: 30070,
};

const API_BASE = 'https://sutvxawqza.execute-api.us-east-1.amazonaws.com/Get/';
const CONTACTS_API = 'https://531s5b8fy6.execute-api.us-east-1.amazonaws.com/UserUpdate_TPS/';
const ALERT_LOG_API = 'https://531s5b8fy6.execute-api.us-east-1.amazonaws.com/Alertlog/Alertlog';
const CONTACTS_ID = 'Contacts';

const Container = ({ onLogout }) => {
  const [deviceOnline, setDeviceOnline] = useState(false);
  const [currentData, setCurrentData] = useState({ 
    netKwh: null, 
    totalKw: null, 
    phase1Kw: null,
    phase2Kw: null,
    phase3Kw: null,
    lastUpdate: null,
    deviceCheckTime: null
  });
  const [dataLog, setDataLog] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [whatsappContact, setWhatsappContact] = useState('');
  const [showContactForm, setShowContactForm] = useState(false);
  const [thresholds, setThresholds] = useState({ '30080': '', '30128': '' });
  const [savedThresholds, setSavedThresholds] = useState({ '30080': '', '30128': '' });
  const [thresholdInputs, setThresholdInputs] = useState({ '30080': '', '30128': '' });
  const [userName, setUserName] = useState('R G Fashion');
  const [selectedType, setSelectedType] = useState('all');
  const [lastEntries, setLastEntries] = useState(10);

  // For the new filter UI
  const [selectedDate, setSelectedDate] = useState(null);
  const [dateMode, setDateMode] = useState('today'); // 'today', 'custom', 'entries'

  const [contacts, setContacts] = useState([]);
  const [clientPagination, setClientPagination] = useState({
    page: 1,
    limit: 50,
    total: 0,
    totalPages: 0
  });
  const [allFilteredData, setAllFilteredData] = useState([]); // Store complete filtered dataset

  // Alert Log States
  const [alertLog, setAlertLog] = useState([]);
  const [alertSelectedDate, setAlertSelectedDate] = useState(null);
  const [alertDateMode, setAlertDateMode] = useState('today');
  const [alertPagination, setAlertPagination] = useState({
    page: 1,
    limit: 50,
    total: 0,
    totalPages: 0
  });
  const [allFilteredAlertData, setAllFilteredAlertData] = useState([]);

  const parseCustomTimestamp = (timestamp) => {
    if (!timestamp || typeof timestamp !== 'string') return null;
    try {
      const [datePart, timePart] = timestamp.split(' ');
      const [year, month, day] = datePart.split('-');
      const [hours, minutes, seconds] = timePart.split(':');
      const date = new Date(+year, +month - 1, +day, +hours, +minutes, +seconds);
      return isNaN(date.getTime()) ? null : date;
    } catch (err) {
      return null;
    }
  };

  const checkDeviceStatus = (timestamp, value, address) => {
    if (value === -404) return false;
    const parsedDate = parseCustomTimestamp(timestamp);
    if (!parsedDate) return false;
    const now = Date.now();
    const last = parsedDate.getTime();
    const diffMinutes = (now - last) / (1000 * 60);
    const phaseAddresses = [ADDRESSES.PHASE1_KW, ADDRESSES.PHASE2_KW, ADDRESSES.PHASE3_KW, ADDRESSES.TOTAL_KW];
    const threshold = phaseAddresses.includes(address) ? 4 : 15;
    return diffMinutes <= threshold && diffMinutes >= -5;
  };

  const fetchCurrentData = useCallback(async () => {
    try {
      setIsLoading(true);
      const allAddresses = `${ADDRESSES.NET_KWH},${ADDRESSES.TOTAL_KW},${ADDRESSES.PHASE1_KW},${ADDRESSES.PHASE2_KW},${ADDRESSES.PHASE3_KW}`;
      const response = await fetch(`${API_BASE}?address=${allAddresses}&last=1`);
      const json = await response.json();

      const kwhItem = json.find(i => i.address === ADDRESSES.NET_KWH) || {};
      const kwItem = json.find(i => i.address === ADDRESSES.TOTAL_KW) || {};
      const phase1Item = json.find(i => i.address === ADDRESSES.PHASE1_KW) || {};
      const phase2Item = json.find(i => i.address === ADDRESSES.PHASE2_KW) || {};
      const phase3Item = json.find(i => i.address === ADDRESSES.PHASE3_KW) || {};

      const kwhValue = kwhItem.value ?? -404;
      const kwValue = kwItem.value ?? -404;
      const phase1Value = phase1Item.value ?? -404;
      const phase2Value = phase2Item.value ?? -404;
      const phase3Value = phase3Item.value ?? -404;

      const energyTimestamp = kwhItem.timestamp;
      const powerTimestamps = [
        kwItem.timestamp,
        phase1Item.timestamp,
        phase2Item.timestamp,
        phase3Item.timestamp
      ].filter(Boolean);

      const deviceCheckTimestamp = powerTimestamps.length > 0 
        ? powerTimestamps.sort((a, b) => new Date(b) - new Date(a))[0] 
        : null;

      setCurrentData({
        netKwh: kwhValue,
        totalKw: kwValue,
        phase1Kw: phase1Value,
        phase2Kw: phase2Value,
        phase3Kw: phase3Value,
        lastUpdate: energyTimestamp,
        deviceCheckTime: deviceCheckTimestamp
      });

      const isOnline = checkDeviceStatus(kwItem.timestamp, kwValue, ADDRESSES.TOTAL_KW) || 
        checkDeviceStatus(phase1Item.timestamp, phase1Value, ADDRESSES.PHASE1_KW) ||
        checkDeviceStatus(phase2Item.timestamp, phase2Value, ADDRESSES.PHASE2_KW) ||
        checkDeviceStatus(phase3Item.timestamp, phase3Value, ADDRESSES.PHASE3_KW);

      setDeviceOnline(isOnline);
    } catch (err) {
      setError(err.message);
      setDeviceOnline(false);
      setCurrentData({ netKwh: 0, totalKw: 0, phase1Kw: 0, phase2Kw: 0, phase3Kw: 0, lastUpdate: null, deviceCheckTime: null });
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Refactored Data Log fetching logic
  const fetchDataLog = useCallback(async () => {
    try {
      const addrParam =
        selectedType === 'net_energy'
          ? ADDRESSES.NET_KWH
          : selectedType === 'total_power'
          ? ADDRESSES.TOTAL_KW
          : selectedType === 'phase1_power'
          ? ADDRESSES.PHASE1_KW
          : selectedType === 'phase2_power'
          ? ADDRESSES.PHASE2_KW
          : selectedType === 'phase3_power'
          ? ADDRESSES.PHASE3_KW
          : `${ADDRESSES.NET_KWH},${ADDRESSES.TOTAL_KW},${ADDRESSES.PHASE1_KW},${ADDRESSES.PHASE2_KW},${ADDRESSES.PHASE3_KW}`;

      const params = new URLSearchParams();
      params.append('address', addrParam);

      const formatToTimestamp = (dateObj) => {
        if (!(dateObj instanceof Date)) return '';
        const yyyy = dateObj.getFullYear();
        const mm = String(dateObj.getMonth() + 1).padStart(2, '0');
        const dd = String(dateObj.getDate()).padStart(2, '0');
        const hh = String(dateObj.getHours()).padStart(2, '0');
        const min = String(dateObj.getMinutes()).padStart(2, '0');
        const ss = String(dateObj.getSeconds()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
      };

      if (dateMode === 'today') {
        const now = new Date();
        const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        params.append('from', formatToTimestamp(yesterday));
        params.append('to', formatToTimestamp(now));
      } else if (dateMode === 'custom' && selectedDate) {
        const startOfDay = new Date(selectedDate);
        startOfDay.setHours(0, 1, 0, 0);
        const endOfDay = new Date(selectedDate);
        endOfDay.setHours(23, 59, 59, 999);
        params.append('from', formatToTimestamp(startOfDay));
        params.append('to', formatToTimestamp(endOfDay));
      } else {
        params.append('last', lastEntries);
      }

      const res = await fetch(`${API_BASE}?${params.toString()}`);
      const json = await res.json();

      const sorted = json.sort((a, b) => {
        const timeA = parseCustomTimestamp(a.timestamp);
        const timeB = parseCustomTimestamp(b.timestamp);
        return (timeB || 0) - (timeA || 0);
      });

      const processedData = sorted.map((item, i) => ({
        id: i + 1,
        timestamp: item.timestamp,
        address: item.address,
        value: item.value ?? 0,
        unit: item.address === ADDRESSES.NET_KWH ? 'kWh' : 'kW',
        type: item.address === ADDRESSES.NET_KWH ? 'Total Consumption' :
              item.address === ADDRESSES.TOTAL_KW ? 'Total Load' :
              item.address === ADDRESSES.PHASE1_KW ? 'Phase 1 Load' :
              item.address === ADDRESSES.PHASE2_KW ? 'Phase 2 Load' :
              item.address === ADDRESSES.PHASE3_KW ? 'Phase 3 Load' : 'Unknown',
      }));

      setAllFilteredData(processedData);

      // Set up pagination for date queries or last entries
      const total = processedData.length;
      const currentLimit = dateMode === 'entries' ? lastEntries : 50;
      const totalPages = Math.ceil(total / currentLimit);

      setClientPagination({
        page: 1,
        limit: currentLimit,
        total: total,
        totalPages
      });

      const startIndex = 0;
      const endIndex = Math.min(currentLimit, total);
      setDataLog(processedData.slice(startIndex, endIndex));

    } catch (err) {
      setDataLog([]);
      setAllFilteredData([]);
    }
  }, [lastEntries, selectedType, selectedDate, dateMode]);

  // Alert Log fetching logic
  const fetchAlertLog = useCallback(async () => {
    try {
      const formatToAlertTimestamp = (dateObj) => {
        if (!(dateObj instanceof Date)) return '';
        const yyyy = dateObj.getFullYear();
        const mm = String(dateObj.getMonth() + 1).padStart(2, '0');
        const dd = String(dateObj.getDate()).padStart(2, '0');
        const hh = String(dateObj.getHours()).padStart(2, '0');
        const min = String(dateObj.getMinutes()).padStart(2, '0');
        const ss = String(dateObj.getSeconds()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
      };

      let fromDate, toDate;

      if (alertDateMode === 'today') {
        const now = new Date();
        const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        fromDate = formatToAlertTimestamp(yesterday);
        toDate = formatToAlertTimestamp(now);
      } else if (alertDateMode === 'custom' && alertSelectedDate) {
        // For selected date, get data from previous day 00:00 to selected day 23:59
        const selectedDay = new Date(alertSelectedDate);
        const previousDay = new Date(selectedDay.getTime() - 24 * 60 * 60 * 1000);
        
        previousDay.setHours(0, 0, 0, 0);
        selectedDay.setHours(23, 59, 59, 999);
        
        fromDate = formatToAlertTimestamp(previousDay);
        toDate = formatToAlertTimestamp(selectedDay);
      } else {
        // Default to today if no valid mode
        const now = new Date();
        const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        fromDate = formatToAlertTimestamp(yesterday);
        toDate = formatToAlertTimestamp(now);
      }

      const url = `${ALERT_LOG_API}?from_date=${encodeURIComponent(fromDate)}&to_date=${encodeURIComponent(toDate)}`;
      const res = await fetch(url);
      const json = await res.json();

      // Process the alert data (adjust this based on your API response structure)
      const processedAlertData = (Array.isArray(json) ? json : []).map((item, i) => ({
        id: i + 1,
        timestamp: item.timestamp || item.created_at || item.date,
        message: item.message || item.alert_message || item.description,
        type: item.type || item.alert_type || 'Alert',
        severity: item.severity || item.level || 'Medium',
        value: item.value || item.threshold_value || 'N/A'
      }));

      // Sort by timestamp (newest first)
      const sorted = processedAlertData.sort((a, b) => {
        const timeA = parseCustomTimestamp(a.timestamp);
        const timeB = parseCustomTimestamp(b.timestamp);
        return (timeB || 0) - (timeA || 0);
      });

      setAllFilteredAlertData(sorted);

      // Set up pagination
      const total = sorted.length;
      const currentLimit = 50;
      const totalPages = Math.ceil(total / currentLimit);

      setAlertPagination({
        page: 1,
        limit: currentLimit,
        total: total,
        totalPages
      });

      const startIndex = 0;
      const endIndex = Math.min(currentLimit, total);
      setAlertLog(sorted.slice(startIndex, endIndex));

    } catch (err) {
      console.error('Error fetching alert log:', err);
      setAlertLog([]);
      setAllFilteredAlertData([]);
    }
  }, [alertSelectedDate, alertDateMode]);

  const handleClientPageChange = useCallback((newPage) => {
    const { limit } = clientPagination;
    const startIndex = (newPage - 1) * limit;
    const endIndex = Math.min(startIndex + limit, allFilteredData.length);
    setDataLog(allFilteredData.slice(startIndex, endIndex));
    setClientPagination(prev => ({
      ...prev,
      page: newPage
    }));
  }, [clientPagination.limit, allFilteredData]);

  const handleClientLimitChange = useCallback((newLimit) => {
    const totalPages = Math.ceil(allFilteredData.length / newLimit);
    const newPage = 1;
    const startIndex = 0;
    const endIndex = Math.min(newLimit, allFilteredData.length);
    setDataLog(allFilteredData.slice(startIndex, endIndex));
    setClientPagination({
      page: newPage,
      limit: newLimit,
      total: allFilteredData.length,
      totalPages
    });
  }, [allFilteredData]);

  // Alert pagination handlers
  const handleAlertPageChange = useCallback((newPage) => {
    const { limit } = alertPagination;
    const startIndex = (newPage - 1) * limit;
    const endIndex = Math.min(startIndex + limit, allFilteredAlertData.length);
    setAlertLog(allFilteredAlertData.slice(startIndex, endIndex));
    setAlertPagination(prev => ({
      ...prev,
      page: newPage
    }));
  }, [alertPagination.limit, allFilteredAlertData]);

  const handleAlertLimitChange = useCallback((newLimit) => {
    const totalPages = Math.ceil(allFilteredAlertData.length / newLimit);
    const newPage = 1;
    const startIndex = 0;
    const endIndex = Math.min(newLimit, allFilteredAlertData.length);
    setAlertLog(allFilteredAlertData.slice(startIndex, endIndex));
    setAlertPagination({
      page: newPage,
      limit: newLimit,
      total: allFilteredAlertData.length,
      totalPages
    });
  }, [allFilteredAlertData]);

  const fetchContacts = useCallback(async () => {
    try {
      const res = await fetch(`${CONTACTS_API}?id=${CONTACTS_ID}`);
      const json = await res.json();
      const contacts = json?.value?.split(',').map(c => c.trim()).filter(Boolean) || [];
      setContacts(contacts);
    } catch (err) {
      setContacts([]);
    }
  }, []);

  const fetchThresholds = useCallback(async () => {
    try {
      const ids = ['30080', '30128'];
      const results = {};
      await Promise.all(ids.map(async (id) => {
        const res = await fetch(`${CONTACTS_API}?id=${id}`);
        const json = await res.json();
        results[id] = json?.value ?? '';
      }));
      setSavedThresholds(results);
      setThresholdInputs(results);
    } catch {}
  }, []);

  const fetchUserName = useCallback(async () => {
    try {
      const res = await fetch(`${CONTACTS_API}?id=user`);
      const json = await res.json();
      if (json?.value) setUserName(json.value);
    } catch (err) {
      // silent error
    }
  }, []);

  useEffect(() => {
    fetchCurrentData();
    fetchDataLog();
    fetchAlertLog();
    fetchContacts();
    fetchThresholds();
    fetchUserName();
    const interval = setInterval(fetchCurrentData, 15 * 60 * 1000);
    return () => clearInterval(interval);
  }, [fetchCurrentData, fetchDataLog, fetchAlertLog, fetchContacts, fetchThresholds, fetchUserName]);

  // Share Data
  const formatDateTime = (ts) => {
    if (!ts) return 'N/A';
    const [datePart, timePart] = ts.split(' ');
    const [year, month, day] = datePart.split('-');
    return `${day}-${month}-${year} ${timePart}`;
  };

  const shareData = async () => {
    const sharePayload = {
      title: 'EMS – Data Report',
      text: `Device Status: ${deviceOnline ? 'Online' : 'Offline'}\nNet: ${currentData.netKwh} kWh\nPower: ${currentData.totalKw} kW\nLast: ${formatDateTime(currentData.lastUpdate)}`,
      url: window.location.href,
    };
    try {
      if (navigator.share && navigator.canShare(sharePayload)) await navigator.share(sharePayload);
      else {
        await navigator.clipboard.writeText(`${sharePayload.title}\n${sharePayload.text}\n${sharePayload.url}`);
        alert('Copied to clipboard');
      }
    } catch (err) {
      alert('Share failed');
    }
  };

  return (
    <Body
      deviceOnline={deviceOnline}
      currentData={currentData}
      dataLog={dataLog}
      isLoading={isLoading}
      error={error}
      thresholds={thresholds}
      setThresholds={setThresholds}
      selectedType={selectedType}
      setSelectedType={setSelectedType}
      lastEntries={lastEntries}
      setLastEntries={setLastEntries}
      shareData={shareData}
      formatDateTime={formatDateTime}
      whatsappContact={whatsappContact}
      setWhatsappContact={setWhatsappContact}
      showContactForm={showContactForm}
      setShowContactForm={setShowContactForm}
      contacts={contacts}
      setContacts={setContacts}
      fetchCurrentData={fetchCurrentData}
      fetchDataLog={fetchDataLog}
      CONTACTS_API={CONTACTS_API}
      fetchThresholds={fetchThresholds}
      onLogout={onLogout}
      CONTACTS_ID={CONTACTS_ID}
      userName={userName}
      setUserName={setUserName}
      savedThresholds={savedThresholds}
      thresholdInputs={thresholdInputs}
      setThresholdInputs={setThresholdInputs}
      clientPagination={clientPagination}
      onClientPageChange={handleClientPageChange}
      onClientLimitChange={handleClientLimitChange}
      allFilteredData={allFilteredData}
      selectedDate={selectedDate}
      setSelectedDate={setSelectedDate}
      dateMode={dateMode}
      setDateMode={setDateMode}
      // Alert Log Props
      alertLog={alertLog}
      allFilteredAlertData={allFilteredAlertData}
      alertSelectedDate={alertSelectedDate}
      setAlertSelectedDate={setAlertSelectedDate}
      alertDateMode={alertDateMode}
      setAlertDateMode={setAlertDateMode}
      alertPagination={alertPagination}
      onAlertPageChange={handleAlertPageChange}
      onAlertLimitChange={handleAlertLimitChange}
      fetchAlertLog={fetchAlertLog}
    />
  );
};

export default Container;
