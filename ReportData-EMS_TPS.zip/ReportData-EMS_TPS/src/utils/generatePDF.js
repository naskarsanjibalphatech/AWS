import jsPDF from 'jspdf';
import dayjs from 'dayjs';
import customParseFormat from 'dayjs/plugin/customParseFormat';
dayjs.extend(customParseFormat);
import autoTable from 'jspdf-autotable';

export const generatePDF = ({
  dataLog,
  generatedAt,
  meterName = "Meter 06",
  fromDate,
  toDate,
  lastEntries,
  userName = 'User',
}) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  const formatTimestamp = (ts) => {
    if (!ts) return 'N/A';
    const parsed = dayjs(ts);
    return parsed.isValid() ? parsed.format('DD-MM-YYYY HH:mm:ss') : 'N/A';
  };

  const format = (d) =>
    `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;

  // HEADER BAR
  const headerY = 15;
  doc.setFillColor(0, 51, 102);
  doc.rect(0, headerY, pageWidth, 12, 'F');

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text('Energy Management System Report', pageWidth / 2, headerY + 8, { align: 'center' });

  // Subheader
  const subheaderStartY = 32;
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0);
  doc.text(`Company: TPS Real Estate Pvt Ltd`, pageWidth / 2, subheaderStartY, { align: 'center' });
  doc.text(`User Name: ${userName} | Meter No. 43240123 | Unit No: 06`, pageWidth / 2, subheaderStartY + 5, { align: 'center' });
  doc.text(`Generated On: ${generatedAt || 'N/A'} Hrs`, pageWidth / 2, subheaderStartY + 10, { align: 'center' });

  let reportRangeText = '';
  if (fromDate && toDate) {
    reportRangeText = `From ${formatTimestamp(fromDate)} Hrs to ${formatTimestamp(toDate)} Hrs`;
  } else {
    reportRangeText = `Last ${lastEntries} entries`;
  }
  doc.text(reportRangeText, pageWidth / 2, subheaderStartY + 20, { align: 'center' });

  // DATA SUMMARY (Ignoring negative values)
  const positiveValues = dataLog
    .map(d => Number(d.value))
    .filter(v => v >= 0);

  const max = positiveValues.length ? Math.max(...positiveValues) : 0;
  const min = positiveValues.length ? Math.min(...positiveValues) : 0;
  const avg = positiveValues.length
    ? positiveValues.reduce((sum, v) => sum + v, 0) / positiveValues.length
    : 0;

  const maxEntry = dataLog.find(d => Number(d.value) === max && Number(d.value) >= 0);
  const minEntry = dataLog.find(d => Number(d.value) === min && Number(d.value) >= 0);

  const unitCounts = dataLog.reduce((acc, d) => {
    if (Number(d.value) >= 0) {
      acc[d.unit] = (acc[d.unit] || 0) + 1;
    }
    return acc;
  }, {});
  const avgUnit = Object.entries(unitCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '';
  const maxUnit = maxEntry?.unit || '';
  const minUnit = minEntry?.unit || '';

  const summaryStartY = subheaderStartY + 29;

  doc.setDrawColor(200);
  doc.line(14, summaryStartY - 6, pageWidth - 14, summaryStartY - 6);

  doc.setFontSize(11);
  doc.setTextColor(0);
  doc.text('DATA SUMMARY', 14, summaryStartY);

  doc.setFontSize(10);
  doc.text(`Max Value: ${max.toFixed(3)} ${maxUnit} (${formatTimestamp(maxEntry?.timestamp)})`, 14, summaryStartY + 7);
  doc.text(`Min Value: ${min.toFixed(3)} ${minUnit} (${formatTimestamp(minEntry?.timestamp)})`, 14, summaryStartY + 14);
  doc.text(`Avg Value: ${avg.toFixed(3)} ${avgUnit}`, 14, summaryStartY + 21);

  // TABLE DATA - Updated to include TYPE column
  const tableData = dataLog.map(row => [
    row.id,
    formatTimestamp(row.timestamp),
    row.type || 'Unknown',  // Added TYPE column
    row.value,
    row.unit,
  ]);

  // TABLE WITH AUTOTABLE - Removed columnStyles to let table fill page width
  autoTable(doc, {
    head: [['ID', 'Timestamp', 'Type', 'Value', 'Unit']], // Added 'Type' header
    body: tableData,
    startY: summaryStartY + 30,
    margin: { top: 20 },
    styles: {
      fontSize: 8,
      cellPadding: 3,
    },
    headStyles: {
      fillColor: [0, 112, 192],
      textColor: [255, 255, 255],
    },
    // Removed columnStyles - let autoTable automatically distribute column widths
    rowPageBreak: 'auto',
    pageBreak: 'auto',
    pageBreakBefore: (data, row, index) => index > 0 && index % 30 === 0
  });

  // ➤ AFTER autoTable is done, add correct footers
  const pageCount = doc.internal.getNumberOfPages();

  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);

    // ➤ Continuation Header (for page 2+)
    if (i > 1) {
      doc.setFillColor(255, 255, 255);
      doc.rect(0, 0, pageWidth, 20, 'F');
      doc.setFontSize(12);
      doc.setTextColor(0);
      doc.setFont('helvetica', 'bold');
      doc.text('Energy Management System Report (Contd.)', pageWidth / 2, 14, { align: 'center' });
    }

    // ➤ Footer: Page x of y
    doc.setFontSize(9);
    doc.setTextColor(120);
    doc.text(`Page ${i} of ${pageCount}`, pageWidth / 2, pageHeight - 10, { align: 'center' });

    // ➤ Footer: Developer Credit
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(110);
    doc.text('Developed by Alphatech Solutions', pageWidth / 2, pageHeight - 5, { align: 'center' });

    doc.setTextColor(130);
    doc.textWithLink('www.alphatechsolutions.in', pageWidth / 2, pageHeight - 2, {
      url: 'https://www.alphatechsolutions.in',
      align: 'center',
    });
  }

  doc.save(`energy-report-${new Date().toISOString().split('T')[0]}.pdf`);
};
